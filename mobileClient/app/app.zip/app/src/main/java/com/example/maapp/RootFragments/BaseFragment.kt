package com.example.maapp.RootFragments

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.maapp.R
import com.ncapdevi.fragnav.FragNavController



abstract class BaseFragment : Fragment() {

    interface FragmentNavigation {
        fun pushFragment(fragment: BaseFragment)
        fun replaceFragment(fragment: BaseFragment)
        fun popFragment()
        fun isRootFragment(): Boolean
    }

    abstract val layoutRes: Int

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        inflater.inflate(layoutRes, container, false)

    override fun onAttach(context: Context) {
        super.onAttach(context)
        setHasOptionsMenu(true)
        if (context is FragmentNavigation) {
            fragmentNavigation = context
        }
    }

    lateinit var fragmentNavigation: FragmentNavigation
    lateinit var navController: FragNavController

    fun configureToolbar(toolbar : Toolbar) {
        (context as AppCompatActivity).setSupportActionBar(toolbar)
        (context as AppCompatActivity).supportActionBar?.let {
            it.setDisplayHomeAsUpEnabled(true)
            it.setDisplayShowHomeEnabled(true)
            it.setDisplayShowTitleEnabled(true)
            it.setHomeAsUpIndicator(R.drawable.ic_arrow_back)
        }
        toolbar.setNavigationOnClickListener {
            (context as AppCompatActivity).onBackPressed()
        }
    }
}