package com.example.maapp.CustomTestsLogic

data class WallCharacteristic (var height: Int = 0, var length: Double = 0.0, var breakCount: Int = 0)