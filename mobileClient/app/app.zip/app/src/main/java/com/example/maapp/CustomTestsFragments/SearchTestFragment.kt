package com.example.maapp.CustomTestsFragments

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.support.design.widget.BottomSheetBehavior
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.example.maapp.R
import com.example.maapp.RootFragments.BaseFragment
import com.example.maapp.CustomTestsLogic.Tests
import com.example.maapp.RootFragments.MainActivity
import com.example.maapp.ServerConnection.ConnectionService
import kotlinx.android.synthetic.main.activity_search_test.*
import kotlinx.android.synthetic.main.wall_bottom_sheet.*
import kotlinx.coroutines.*

class SearchTestFragment : BaseFragment() {

    override val layoutRes: Int = R.layout.activity_search_test
    private lateinit var sheetBehavior: BottomSheetBehavior<LinearLayout>
    private var checkFlag = true
    private var testJob = Job()
    var bottomSheetFlag = true
    var isBound = false
    lateinit var mA: MainActivity

    var connectionService: ConnectionService? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sheetBehavior = BottomSheetBehavior.from<LinearLayout>(bottom_sheet)
        //low_sheet_content.text = getString(R.string.bottom_search_sheet_content)
        search_proc_rb.isChecked = true

        val intent = Intent(activity, ConnectionService::class.java)
        activity?.bindService(intent,myConnection, Context.BIND_AUTO_CREATE)

        mA = activity as MainActivity

        sheetBehavior.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN -> {
                    }
                    BottomSheetBehavior.STATE_EXPANDED ->{
                        search_start_test.visibility = View.INVISIBLE
                    }
                    BottomSheetBehavior.STATE_COLLAPSED -> {
                        search_start_test.visibility = View.VISIBLE
                    }
                    BottomSheetBehavior.STATE_DRAGGING -> {
                        search_start_test.visibility = View.INVISIBLE
                    }
                    BottomSheetBehavior.STATE_SETTLING -> {
                    }
                }
            }
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
            }
        })

        /*technic_ref_search_test.setOnClickListener {
            val toast = Toast.makeText(activity,"В основе алгоритма лежит многократное" +
                    " повторение либо операции вида a[i] = b[i] * c[i] + d[i], либо" +
                    " операции вида a = b * c + d", Toast.LENGTH_LONG)
            toast.setGravity(Gravity.CENTER,0,0)
            toast.show()
        }*/

        btn_go_search_test.setOnClickListener{
            fragmentNavigation.popFragment()
        }

        search_start_test.setOnClickListener{
            startTest(view)
        }

        bottom_sheet.setOnClickListener{

            if (bottomSheetFlag){
                sheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                bottomSheetFlag = false
            }
            else {
                sheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
                bottomSheetFlag = true
            }
        }

        search_proc_mem_rb.setOnClickListener{
            checkFlag = false
        }
        search_proc_rb.setOnClickListener{

            checkFlag = true
        }


    }

    private val myConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName,
                                        service: IBinder
        ) {
            val binder = service as ConnectionService.MyLocalBinder
            connectionService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            isBound = false
        }
    }

    private fun getRecords(stringValues: String) : ArrayList<String> {

        var someArr : ArrayList<String> = ArrayList(4)


        var searchTestString = stringValues.substringAfter(']')


        var resString = searchTestString.substringAfter("dev': '")

        val worstDevice = resString.substringBefore('\'')
        var worstResult = resString.substringAfter("res': ")
        worstResult = worstResult.substringBefore('}')

        resString = resString.substringAfterLast("dev': '")

        val topDevice = resString.substringBefore('\'')
        var topResult = resString.substringAfter("res': ")
        topResult = topResult.substringBefore('}')

        println(worstDevice)
        println(worstResult)
        println(topDevice)
        println(topResult)

        someArr.add(worstDevice)
        someArr.add(worstResult)
        someArr.add(topDevice)
        someArr.add(topResult)
        return someArr
    }

    suspend fun startProgressBar (view: View) {
        var progressBarStatus = 0
        while (progressBarStatus < 100) {
            progressBarStatus += 1

            try {
                delay(140)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }

            textView17.text = "$progressBarStatus of 100%"
            wallTestProgressBar4.secondaryProgress = progressBarStatus
        }
        delay(3000)
    }

    fun startTest(view: View){
        var testResult: ArrayList<Int>
        var comparedDevices: ArrayList<String> = ArrayList(4)
        var sendBuf: ArrayList<Double> = ArrayList(3)
        textView18.text = ""
        textView18.visibility = View.INVISIBLE
        wallTestProgressBar4.visibility = View.VISIBLE
        textView17.text=""
        textView17.visibility = View.VISIBLE
        card_result_search_test.visibility = View.INVISIBLE

        testJob = GlobalScope.launch(Dispatchers.Main) {
            val job = launch {
                startProgressBar(view)
            }
            val asyncVal = async {
                val testObject = Tests()
                if (checkFlag) {
                    testObject.searchTest(view)
                }
                else{
                    testObject.quadraticComplexitySearchTest(view)
                }
            }
            job.join()
            println(asyncVal.await())
            testResult = asyncVal.await()
            wallTestProgressBar4.visibility = View.INVISIBLE
            textView17.visibility = View.INVISIBLE
            textView18.clearComposingText()
            textView18.visibility = View.VISIBLE
            card_result_search_test.visibility = View.VISIBLE
            comparedDevices = getRecords(mA.getD()!!)
            if (testResult[0] == 1){
                textView18.text = "Результат теста - поиск в пределеах группы двух братьев удался."
                own_res_search_test.text = "Ваш результат - проверено ${testResult[1]} человек(a)"
                best_res_search_test.text = "Лучший результат - проверено ${comparedDevices[3]} человек(a)"
                worst_res_search_test.text = "Худший результат - проверено ${comparedDevices[1]} человек(а)"
            }else{
                textView18.text = "Результат теста - поиск в пределеах группы двух братьев не удался."
                own_res_search_test.text = "Ваш результат - проверено ${testResult[1]} человек(a)"
                best_res_search_test.text = "Лучший результат - проверено ${comparedDevices[3]} человек(a)"
                worst_res_search_test.text = "Худший результат - проверено ${comparedDevices[1]} человек(а)"
            }

            sendBuf.add(2.0)
            sendBuf.add(testResult[1].toDouble())
            sendBuf.add(0.0)

            connectionService?.sendRecordToServ(sendBuf)
        }


    }
}