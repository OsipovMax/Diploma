package com.example.maapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu

class bottomTEST : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bottom_test)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.tests_menu,menu)
        return true
    }
}
