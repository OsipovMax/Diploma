package com.example.maapp.CustomTestsFragments

import android.bluetooth.BluetoothAssignedNumbers
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.print.PrintAttributes
import android.support.constraint.ConstraintLayout
import android.support.constraint.ConstraintSet
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.Snackbar
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.Toast
import com.example.android.roomdevice.Device
import com.example.android.roomdevice.DeviceRepository
import com.example.android.roomdevice.DeviceRoomDatabase
import com.example.maapp.ServerConnection.ConnectionService
import com.example.maapp.R
import com.example.maapp.RootFragments.BaseFragment
import com.example.maapp.CustomTestsLogic.Tests
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.HorizontalBarChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.LegendEntry
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.LargeValueFormatter
import kotlinx.android.synthetic.main.activity_wall_test.*
import kotlinx.android.synthetic.main.wall_bottom_sheet.*
import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext
import kotlin.random.Random
import android.support.transition.*
import android.support.v7.widget.SearchView
import android.view.*
import com.example.maapp.RootFragments.MainActivity
import kotlinx.android.synthetic.main.activity_bottom_test.*
import kotlinx.android.synthetic.main.activity_leader_board.*
import kotlinx.android.synthetic.main.res_bottom_sheet.*
import kotlinx.android.synthetic.main.scene_upload_results.*
import java.util.zip.Inflater

class TestExecution : BaseFragment() {
    lateinit var barChartView : BarChart
    override val layoutRes: Int = R.layout.activity_wall_test
    private lateinit var sheetBehavior: BottomSheetBehavior<LinearLayout>
    private lateinit var sheetBehaviorResult: BottomSheetBehavior<LinearLayout>

    var connectionService: ConnectionService? = null
    var isBound = false

    private var testJob = Job()
    private var tempJob = Job()



    var checkFlag = false
    var bottomSheetFlag = true

    var globalResult = 0.0

    private var parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)
    private var repository: DeviceRepository? = null


    lateinit var topDev : Device
    lateinit var worstDev : Device

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.tests_menu, menu)

        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.proc -> {
                val snackbar = Snackbar.make(view!!, "Вы выбрали режим тестирования процессора",
                    Snackbar.LENGTH_LONG).setAction("Action", null)
                snackbar.show()
                checkFlag = false
                println("PROC_ONLY")
            }
            R.id.mem -> {
                val snackbar = Snackbar.make(view!!, "Вы выбрали режим тестирования процессора и памяти",
                    Snackbar.LENGTH_LONG).setAction("Action", null)
                snackbar.show()
                checkFlag = true
                println("MEM + PROC")
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        configureToolbar(wall_test_tb)
        val intent = Intent(activity, ConnectionService::class.java)
        activity?.bindService(intent,myConnection, Context.BIND_AUTO_CREATE)


        scope.launch(Dispatchers.Default) {
            val deviceDao = DeviceRoomDatabase.getDatabase(activity!!.applicationContext, scope, "").deviceDao()

            repository = DeviceRepository(deviceDao, "")
            topDev = repository!!.getTop()

            worstDev = repository!!.getWorst()

            println(topDev)
            println(worstDev)

            bestDev.text = topDev.device
            yourDev.text = "Mobile Phone"
            worstDevice.text = worstDev.device
        }

        sheetBehavior = BottomSheetBehavior.from<LinearLayout>(bottom_sheet)
        sheetBehavior.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN -> {
                    }
                    BottomSheetBehavior.STATE_EXPANDED ->{
                    }
                    BottomSheetBehavior.STATE_COLLAPSED -> {
                    }
                    BottomSheetBehavior.STATE_DRAGGING -> {
                    }
                    BottomSheetBehavior.STATE_SETTLING -> {
                    }
                }
            }
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
            }
        })

        sheetBehaviorResult = BottomSheetBehavior.from<LinearLayout>(res_bottom_sheet)
        sheetBehaviorResult.setBottomSheetCallback(object: BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(res_bottom_sheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN -> {
                    }
                    BottomSheetBehavior.STATE_EXPANDED ->{
                    }
                    BottomSheetBehavior.STATE_COLLAPSED -> {
                    }
                    BottomSheetBehavior.STATE_DRAGGING -> {
                    }
                    BottomSheetBehavior.STATE_SETTLING -> {
                    }
                }
            }
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
            }
        })
        button8.setOnClickListener {
            startTest(view)
        }
        bottom_sheet.setOnClickListener{
            if (bottomSheetFlag){
                sheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                bottomSheetFlag = false
            }
            else {
                sheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
                bottomSheetFlag = true
            }
        }
        showResult.setOnClickListener{
            //sheetBehaviorResult.state = BottomSheetBehavior.STATE_EXPANDED
            val sheetResultDialog = ResultsTestDialog()
            val sheetStringTeg = "showDialog"
            sheetResultDialog.show(activity!!.supportFragmentManager, sheetStringTeg)
        }

        populateGraphData(0f,0f,0f)
        movementButton()
    }



    private val myConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName,
                                        service: IBinder
        ) {
            val binder = service as ConnectionService.MyLocalBinder
            connectionService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            isBound = false
        }
    }


    fun showTopRecord(res: Double){
        val str = connectionService!!.localStorage
        println(str)
        var tempBuf = ""
        var count = 0
        var localId = ""
        var localDev = ""
        var localBrickPer = ""
        var localLengthPer = ""
        var localSystemPar = ""
        for (char in str) {
            if (char != '/') {
                tempBuf += char
            } else {
                when (count) {
                    0 -> localId = tempBuf
                    1 -> localDev = tempBuf
                    2 -> localBrickPer = tempBuf
                    3 -> localLengthPer = tempBuf
                    4 -> localSystemPar = tempBuf
                }
                tempBuf = ""
                count++
            }
        }

       /* if (res > localLengthPer.toDouble()) {

            textView9.text = "Результат теста - $res м. Ваше устройство показало результат" +
                    "на ${Math.round((res / localLengthPer.toDouble()) * 100)} % лучше, чем $localDev"
        }
        else {
            textView9.text = "Результат теста - $res м. Ваше устройство показало результат" +
                    "на ${Math.round((localLengthPer.toDouble() / res) * 100)} % хуже, чем $localDev"

        }*/
    }


    suspend fun startProgressBar (view: View) {
        var progressBarStatus = 0
        while (progressBarStatus < 100) {
            progressBarStatus += 1

            try {
                delay(140)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }

            //textView10.text = "$progressBarStatus of 100%"
            //wallTestProgressBar.secondaryProgress = progressBarStatus
        }
        delay(3000)
    }


    fun startTest(view: View) {
        var testResult: Double
        var testResult1: Int


        var sendBuf: ArrayList<Double> = ArrayList(3)
        //textView9.text = ""
        //textView9.visibility = View.INVISIBLE
        //wallTestProgressBar.visibility = View.VISIBLE
        //textView10.text = ""
        //textView10.visibility = View.VISIBLE
        showResult.visibility = View.INVISIBLE
        //card_result.visibility = View.INVISIBLE

        testJob = GlobalScope.launch(Dispatchers.Main) {
            val job = launch {
                //wallTestProgressBar.visibility = View.VISIBLE
                //startProgressBar(view)
                stackChart(view)
            }
            val asyncVal = async {
                val testObject = Tests()


                println(topDev)
                println(worstDev)

                testObject.characteristicFunctionBuildWall(view,checkFlag)
                //testObject.unionWallSection(returnValue)
            }
            job.join()
            println(asyncVal.await())
            testResult = asyncVal.await()[0].length
            testResult1 = asyncVal.await()[0].breakCount

            globalResult = testResult

            bestVal.text = "${topDev.lengthPerfomance}"
            yourVal.text = "${testResult}"
            worstVal.text = "${worstDev.lengthPerfomance}"
            //wallTestProgressBar.visibility = View.INVISIBLE
            //textView10.visibility = View.INVISIBLE
            //textView9.clearComposingText()
            //textView9.visibility = View.VISIBLE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            //textView9.text = "Результат теста - $testResult м"
            //showTopRecord(testResult)

            //card_result.visibility = View.INVISIBLE

            //best_res.text = "Лучший результат по тесту - ${topDev.lengthPerfomance}"
            //worst_res.text = "Худший результат по тесту - ${worstDev.lengthPerfomance}"
            //own_res.text = "Ваш результат по тесту - ${testResult}"

            /*
            if (worstDev.lengthPerfomance > testResult){
                textView9.text = "Ваше устройство показало худший результат среди устройств " +
                        " в ${Math.round(( topDev!!.lengthPerfomance / testResult))} раз хуже,чем " +
                        " ${topDev.device}."

            } else {

                textView9.text = "Ваше устройство показало результат в " +
                        " ${Math.round((testResult / worstDev!!.lengthPerfomance))} раз лучше,чем " +
                        " ${worstDev.device} (последнее место в рейтинге) и в ${Math.round((topDev!!.lengthPerfomance / testResult))} раз хуже,чем " +
                        " ${topDev.device}(первое место в рейтинге)."
            }
            */

            sendBuf.add(0.0)
            sendBuf.add(testResult)
            sendBuf.add(testResult1.toDouble())

            connectionService?.sendRecordToServ(sendBuf)
            bounceButton()
        }

    }

    override fun onDestroy() {
        activity?.unbindService(myConnection)
        super.onDestroy()
    }



    fun populateGraphData(a : Float, b: Float, c: Float) {
        barChartView = chartConsumptionGraph

        val barWidth = 2f
        val yValueGroup1 = ArrayList<BarEntry>()
        val barDataSet1: BarDataSet
        val barData: BarData
        val legend = barChartView.legend
        val legendEntries = arrayListOf<LegendEntry>()
        val xAxis = barChartView.xAxis
        val leftAxis = barChartView.axisLeft

        var xAxisValues = ArrayList<String>()
        xAxisValues.add("Худший")
        xAxisValues.add("Ваш")
        xAxisValues.add("Лучший")


        yValueGroup1.add(BarEntry(2f, a.toFloat()))
        yValueGroup1.add(BarEntry(6f, b.toFloat()))
        yValueGroup1.add(BarEntry(10f, c.toFloat()))

        barDataSet1 = BarDataSet(yValueGroup1, "")
        barDataSet1.setColors(Color.GRAY, Color.DKGRAY, Color.BLACK)
        barDataSet1.setDrawIcons(false)
        barDataSet1.setDrawValues(true)

        barData = BarData(barDataSet1)
        barData.setValueFormatter(LargeValueFormatter())

        barChartView.description.isEnabled = false
        barChartView.description.textSize = 0f
        barChartView.xAxis.axisMinimum = 0f
        barChartView.xAxis.axisMaximum = 15f
        barChartView.setVisibleXRangeMaximum(12f)
        barChartView.setVisibleXRangeMinimum(12f)
        barChartView.axisRight.isEnabled = true
        barChartView.setScaleEnabled(false)


        barChartView.invalidate()

        legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        legend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
        legend.orientation = Legend.LegendOrientation.VERTICAL
        legend.setDrawInside(false)
        legend.yOffset = 2f
        legend.xOffset = 2f
        legend.yEntrySpace = 1f
        legend.textSize = 5f

        legendEntries.add(LegendEntry("Best", Legend.LegendForm.SQUARE, 10f, 8f, null, Color.GRAY))
        legendEntries.add(LegendEntry("Your", Legend.LegendForm.SQUARE, 10f, 8f, null, Color.DKGRAY))
        legendEntries.add(LegendEntry("Worst", Legend.LegendForm.SQUARE, 10f, 8f, null, Color.BLACK))
        legend.setCustom(legendEntries)

        xAxis.granularity = 1f
        xAxis.isGranularityEnabled = true
        xAxis.setCenterAxisLabels(true)
        xAxis.setDrawGridLines(false)
        xAxis.textSize = 7f
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        //xAxis.valueFormatter = IndexAxisValueFormatter(xAxisValues)
        xAxis.labelCount = 12
        xAxis.mAxisMaximum = 12f
        xAxis.setCenterAxisLabels(true)
        xAxis.setAvoidFirstLastClipping(true)
        xAxis.spaceMin = 4f
        xAxis.spaceMax = 4f



        leftAxis.valueFormatter = LargeValueFormatter()
        leftAxis.setDrawGridLines(false)
        //leftAxis.setDrawAxisLine(true)
        leftAxis.spaceTop = 3f
        leftAxis.axisMinimum = 0f
        //leftAxis.axisMaximum = 500f ///11111111111111

        barChartView.legend.isEnabled = true
        //barChartView.setDrawValueAboveBar(true)
        barChartView.axisRight.axisMinimum = 50000f


        barChartView.axisLeft.setDrawLabels(false)
        barChartView.xAxis.setDrawLabels(false)

        barChartView.data = barData
        barChartView.data.barWidth = barWidth

        barChartView.setVisibleXRange(1f, 12f)
    }

    fun stackChart (view: View) {
        tempJob = GlobalScope.launch(Dispatchers.Main) {
            var bestIncr = 1f
            var yourIncr = 1f
            var worstIncr = 1f
            for (i in 0 until 1000){
                delay(180)
                populateGraphData(bestIncr, yourIncr, worstIncr)
                bestIncr += (topDev.lengthPerfomance.toFloat()/1000f)
                yourIncr += 0.3f
                worstIncr += (worstDev.lengthPerfomance.toFloat()/1000f)
            }
            populateGraphData(topDev.lengthPerfomance.toFloat(),globalResult.toFloat(),worstDev.lengthPerfomance.toFloat())
        }
    }

    fun bounceButton(){
        showResult.visibility = View.VISIBLE
        val animation = AnimationUtils.loadAnimation(context, R.anim.bounce)
        showResult.startAnimation(animation)
    }

    fun movementButton(){
        val animation = AnimationUtils.loadAnimation(context, R.anim.movement)
        button8.startAnimation(animation)
        /*val params = ConstraintLayout.LayoutParams(
            ConstraintLayout.LayoutParams.WRAP_CONTENT,
            ConstraintLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            marginEnd = 10
        }
        button8.layoutParams = params*/
    }

    fun finalWallTestsResults(view: View){

    }

    override fun onDestroyView() {
        tempJob.cancel()
        testJob.cancel()
        super.onDestroyView()
    }
}