package com.example.maapp.RootFragments

import android.os.Bundle
import android.view.View
import com.example.android.roomdevice.DeviceRepository
import com.example.maapp.CustomTestsFragments.BandwidthTestFragment
import com.example.maapp.CustomTestsFragments.SearchTestFragment
import com.example.maapp.CustomTestsFragments.TestExecution
import com.example.maapp.R
import kotlinx.android.synthetic.main.fragment_tests.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlin.coroutines.CoroutineContext

class TestsFragment : BaseFragment() {
    override val layoutRes: Int = R.layout.fragment_tests

    private var parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)


    private var repository: DeviceRepository? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_test_1.setOnClickListener {
            fragmentNavigation.pushFragment(TestExecution())
        }

        btn_test_2.setOnClickListener {
            fragmentNavigation.pushFragment(BandwidthTestFragment())
        }
        btn_test_3.setOnClickListener{
            fragmentNavigation.pushFragment(SearchTestFragment())
        }

    }
}
