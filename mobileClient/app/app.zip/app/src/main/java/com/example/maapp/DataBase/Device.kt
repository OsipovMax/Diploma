package com.example.android.roomdevice

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "DeviceInformation")
data class Device(@PrimaryKey @ColumnInfo(name = "deviceID") val deviceID: Int,
                  @ColumnInfo(name = "Device") val device: String,
                  @ColumnInfo(name = "BrickPerfomance") var brickPerfomance: Int,
                  @ColumnInfo(name = "LengthPerfomance") var lengthPerfomance: Double,
                  @ColumnInfo(name = "SystemParameter") var systemParameter: String)

