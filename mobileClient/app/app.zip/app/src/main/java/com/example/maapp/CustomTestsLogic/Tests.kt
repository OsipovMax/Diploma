package com.example.maapp.CustomTestsLogic

import android.view.View
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.CoroutineContext
import kotlin.random.Random
import kotlin.system.measureTimeMillis

class Tests(
    val generalLength: Int = 32000,
    val generalHeight: Int = 120,
    val threadCount: Int = 1,
    val cycleCount: Int = 1000) {

    val GROUP_SIZE: Int  = 10000
    val AGE: Int = 17
    val HEIGHT: Double = 178.73
    var carCounter = 0

    data class Person (var height: Double = 0.0, var age: Int)


    private var wall: Array<Array<Double>> = Array(100000){Array(generalHeight){0.0}}
    private var firstParam: Array<Double> = Array(cycleCount){3.3}
    private var secondParam: Array<Double> = Array(cycleCount){3.3}
    private var thirdParam: Array<Double> = Array(cycleCount){3.3}
    private var tempParam: Array<Double> = Array(1){0.0}
    private var arrayWallCharacteristic: ArrayList<WallCharacteristic> = ArrayList(threadCount)
    private val arithmeticParameter = 3.3

    private val mtContext = newFixedThreadPoolContext(threadCount, "mtPool")
    private val mutex = Mutex()

    suspend fun CoroutineScope.timeFunctionBuildWall () {
            val resTime = measureTimeMillis {
                val jobs = List(threadCount) {
                    launch {
                        for (i in 0 until generalHeight) {
                            for (j in 0 until (generalLength / threadCount)){
                                for (k in 0 until cycleCount){
                                    wall[i][j] = firstParam[k] * secondParam[k] + thirdParam[k]
                                }
                            }
                        }
                    }
                }
                jobs.forEach{it.join()}
            }
            println("time = $resTime ms")
    }

   suspend fun CoroutineScope.characteristicFunctionBuildWall(action: suspend() -> Unit) {
        val jobs = List(threadCount) {
            launch {
                action()
            }
        }
       jobs.forEach { it.join() }
   }

    suspend fun CoroutineScope.searchFunction(action: suspend() -> Unit) {
        val jobs = List(threadCount) {
            launch {
                action()
            }
        }
        jobs.forEach { it.join() }
    }

    suspend fun characteristicFunctionBuildWall (itemView: View, checkBoxFlag: Boolean) : ArrayList<WallCharacteristic> {
            CoroutineScope(mtContext).characteristicFunctionBuildWall {
                var wallCharacteristic = WallCharacteristic(0, 0.0)
                val beginTime = System.currentTimeMillis()
                var withoutMem = 0.0
                var i: Int = -1
                while (System.currentTimeMillis() - beginTime < 15 * 1000) {
                    i++
                    var temp = System.currentTimeMillis() - beginTime
                    temp = temp / 1000
                    println("time per cycle = $temp")
                    if (checkBoxFlag) {
                        for (j in 0 until generalHeight) {
                            for (k in 0 until (cycleCount)) {
                                wall[i][j] = firstParam[k] * secondParam[k] + thirdParam[k]
                            }
                        }
                    }
                    else {
                        for (j in 0 until generalHeight) {
                            for (k in 0 until cycleCount) {
                                withoutMem = arithmeticParameter * arithmeticParameter + arithmeticParameter
                            }
                        }
                    }
                }
                println("length = $i")
                mutex.withLock {
                    wallCharacteristic.height = generalHeight
                    wallCharacteristic.length = i * 0.25
                    wallCharacteristic.breakCount = wallCharacteristic.height * i
                    arrayWallCharacteristic.add(wallCharacteristic)

                }
            }
            println(arrayWallCharacteristic[0].height.toString())
            println()
        return arrayWallCharacteristic

    }

    fun unionWallSection (resultArrayWall:ArrayList<WallCharacteristic>): Int{
        var brick = 0
        for(it in resultArrayWall){
            brick += it.breakCount
        }
        return brick
    }

    fun personGenerator(personCount : Int) : Array<Person> {
        val personArray = Array(personCount){ Person(0.0, 0) }
        val randomHeight = List(personCount) { Random.nextDouble(130.0,195.0)}
        val randomAge = List(personCount) { Random.nextInt(5,21)}
        val person = Person(HEIGHT, AGE)
        println(randomAge.size)
        for (i in 0 until personCount) {
            personArray[i].age = randomAge[i]
            personArray[i].height = randomHeight[i]
        }
        personArray[1001].age = AGE
        personArray[1001].height = HEIGHT
        return personArray
    }

    private var parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)

    suspend fun quadraticComplexitySearchTest(itemView: View) : ArrayList<Int> {
        var objectsArray = personGenerator(GROUP_SIZE)
        var successFlag = 0
        var resultArray : ArrayList<Int> = ArrayList(2)
        var resultPersonCount = 0
        lateinit var jobs: Job
        for (it in 0 until threadCount) {
            jobs = CoroutineScope(mtContext).launch {
                val beginPosition = it * (objectsArray.size / threadCount)
                val endPosition = (it + 1) * (objectsArray.size / threadCount)
                val beginTime = System.currentTimeMillis()
                println(beginPosition)
                println(endPosition)
                loop@ for (i in beginPosition until endPosition) {
                    resultPersonCount = i

                    for (j in i + 1 until endPosition) {
                        //println("j = ${j}")
                       // for (k in 0 until 100) {
                            for (l in 0 until cycleCount) {
                                tempParam[0] = firstParam[l] * secondParam[l] + thirdParam[l]
                            }
                        //}
                        if ((objectsArray[i].height == objectsArray[j].height)) {
                            successFlag = 1
                        }
                        if (System.currentTimeMillis() - beginTime > 15 * 1000) {
                            break@loop
                        }
                    }
                }

            }

        }
        jobs.join()
        if (successFlag == 1) {
            resultArray.add(1)
            resultArray.add(resultPersonCount)
        }
        else{
            resultArray.add(0)
            resultArray.add(resultPersonCount)
        }
        return resultArray
    }

    suspend fun searchTest(itemView: View) : ArrayList<Int> {
       var objectsArray = personGenerator(GROUP_SIZE)
       var successFlag = 0
        var resultArray : ArrayList<Int> = ArrayList(2)
        var resultPersonCount = 0
       lateinit var jobs: Job


       for (it in 0 until threadCount){
           jobs = CoroutineScope(mtContext).launch {
               val beginPosition = it * (objectsArray.size / threadCount)
               val endPosition = (it + 1) * (objectsArray.size / threadCount)
               val beginTime = System.currentTimeMillis()

               loop@ for (i in beginPosition until endPosition ) {
                   var temp = System.currentTimeMillis() - beginTime
                   resultPersonCount = i
                   for (j in 0 until 100) {
                       for (k in 0 until cycleCount) {
                           tempParam[0] = firstParam[k] * secondParam[k] + thirdParam[k]
                       }
                   }
                   if ((objectsArray[i].height == HEIGHT) and (objectsArray[i].age == AGE)){
                           successFlag = 1
                   }
                   if (System.currentTimeMillis() - beginTime > 15 * 1000){
                       break@loop
                   }
               }
           }
       }
       jobs.join()
       if (successFlag == 1) {
           resultArray.add(1)
           resultArray.add(resultPersonCount)
       }
       else{
           resultArray.add(0)
           resultArray.add(resultPersonCount)
       }
        return resultArray
   }


    suspend fun CoroutineScope.bendWidth(action: suspend() -> Unit) {
        val jobs = List(threadCount) {
            launch {
                action()
            }
        }
        jobs.forEach { it.join() }
    }


    suspend fun bandWidthTest (itemView: View, checkBoxFlag: Boolean): Int {
        CoroutineScope(mtContext).bendWidth {
            val carArray = (1..1000).toMutableList()
            carArray.shuffle()
            var withoutMem = 0.0
            val beginTime = System.currentTimeMillis()
            var localCounter = 0
                var temp = System.currentTimeMillis() - beginTime
                temp = temp / 1000
                println("time per cycle = $temp")
                loop@ for (i in 0 until 10000) {
                    if(checkBoxFlag) {
                        if (carArray[i] % 2 == 0) {
                            for (j in 0 until 100) {
                                for (k in 0 until cycleCount) {
                                    tempParam[0] = firstParam[k] * secondParam[k] + thirdParam[k]
                                }
                            }
                            if (System.currentTimeMillis() - beginTime > 15 * 1000) {
                                break@loop
                            }
                        } else {
                            for (j in 0 until 1000) {
                                for (k in 0 until cycleCount) {
                                    tempParam[0] = firstParam[k] * secondParam[k] + thirdParam[k]
                                }

                            }
                            if (System.currentTimeMillis() - beginTime > 15 * 1000) {
                                break@loop
                            }
                        }
                        localCounter++
                    }
                    else {
                        if (carArray[i] % 2 == 0) {
                            for (j in 0 until 100) {
                                for (k in 0 until cycleCount) {
                                    tempParam[0] = arithmeticParameter * arithmeticParameter + arithmeticParameter
                                }
                            }
                            if (System.currentTimeMillis() - beginTime > 15 * 1000) {
                                break@loop
                            }
                        } else {
                            for (j in 0 until 1000) {
                                for (k in 0 until cycleCount) {
                                    withoutMem = arithmeticParameter * arithmeticParameter + arithmeticParameter
                                }

                            }
                            if (System.currentTimeMillis() - beginTime > 15 * 1000) {
                                break@loop
                            }
                        }
                        localCounter++
                    }
                }
            println(localCounter)
            mutex.withLock {
                carCounter+=localCounter
            }
        }
        println(carCounter)
        return carCounter
    }

}