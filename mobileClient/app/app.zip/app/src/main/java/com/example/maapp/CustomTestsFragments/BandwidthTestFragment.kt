package com.example.maapp.CustomTestsFragments

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.support.design.widget.BottomSheetBehavior
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.example.maapp.R
import com.example.maapp.RootFragments.BaseFragment
import com.example.maapp.CustomTestsLogic.Tests
import com.example.maapp.RootFragments.MainActivity
import com.example.maapp.ServerConnection.ConnectionService
import kotlinx.android.synthetic.main.activity_bandwith_test.*
import kotlinx.android.synthetic.main.wall_bottom_sheet.*
import kotlinx.coroutines.*

class BandwidthTestFragment : BaseFragment() {

    override val layoutRes: Int = R.layout.activity_bandwith_test
    private lateinit var sheetBehavior: BottomSheetBehavior<LinearLayout>
    private var checkFlag = true
    private var testJob = Job()
    var bottomSheetFlag = true
    var isBound = false
    lateinit var mA: MainActivity

    var connectionService: ConnectionService? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val intent = Intent(activity, ConnectionService::class.java)
        activity?.bindService(intent,myConnection, Context.BIND_AUTO_CREATE)

        mA = activity as MainActivity

        sheetBehavior = BottomSheetBehavior.from<LinearLayout>(bottom_sheet)
        //low_sheet_content.text = getString(R.string.bottom_bandwidth_sheet_content)
        bandwidth_proc_rb.isChecked = true

        sheetBehavior.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN -> {
                    }
                    BottomSheetBehavior.STATE_EXPANDED ->{
                        band_start_test.visibility = View.INVISIBLE
                    }
                    BottomSheetBehavior.STATE_COLLAPSED -> {
                        band_start_test.visibility = View.VISIBLE
                    }
                    BottomSheetBehavior.STATE_DRAGGING -> {
                        band_start_test.visibility = View.INVISIBLE
                    }
                    BottomSheetBehavior.STATE_SETTLING -> {
                    }
                }
            }
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
            }
        })

        technic_ref_band_test.setOnClickListener {
            val toast = Toast.makeText(activity,"В основе алгоритма лежит многократное" +
                    " повторение либо операции вида a[i] = b[i] * c[i] + d[i], либо" +
                    " операции вида a = b * c + d", Toast.LENGTH_LONG)
            toast.setGravity(Gravity.CENTER,0,0)
            toast.show()
        }

        btn_go_band_test.setOnClickListener{
            fragmentNavigation.popFragment()
        }

        band_start_test.setOnClickListener{
            startTest(view)
        }

        bottom_sheet.setOnClickListener{

            if (bottomSheetFlag){
                sheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
                bottomSheetFlag = false
            }
            else {
                sheetBehavior.state = BottomSheetBehavior.STATE_COLLAPSED
                bottomSheetFlag = true
            }
        }

        bandwidth_proc_mem_rb.setOnClickListener{
            checkFlag = true
        }
        bandwidth_proc_rb.setOnClickListener{
            checkFlag = false
        }


    }

    private val myConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName,
                                        service: IBinder
        ) {
            val binder = service as ConnectionService.MyLocalBinder
            connectionService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            isBound = false
        }
    }


    private fun getRecords(stringValues: String) : ArrayList<String> {
        var someArr : ArrayList<String> = ArrayList(4)
        val regex = "^.*?]".toRegex()
        val someStr = regex.find(stringValues)!!
        println(someStr.value)

        var resString = someStr.value.substringAfter("dev': '")

        val worstDevice = resString.substringBefore('\'')
        var worstResult = resString.substringAfter("res': ")
        worstResult = worstResult.substringBefore('}')

        resString = resString.substringAfterLast("dev': '")

        val topDevice = resString.substringBefore('\'')
        var topResult = resString.substringAfter("res': ")
        topResult = topResult.substringBefore('}')

        println(worstDevice)
        println(worstResult)
        println(topDevice)
        println(topResult)

        someArr.add(worstDevice)
        someArr.add(worstResult)
        someArr.add(topDevice)
        someArr.add(topResult)
        return someArr
    }

    suspend fun startProgressBar (view: View) {
        var progressBarStatus = 0
        while (progressBarStatus < 100) {
            progressBarStatus += 1

            try {
                delay(140)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }

            textView5.text = "$progressBarStatus of 100%"
            wallTestProgressBar3.secondaryProgress = progressBarStatus
        }
        delay(3000)
    }

    fun startTest(view: View){
        var testResult: Int
        var sendBuf: ArrayList<Double> = ArrayList(3)
        var comparedDevices: ArrayList<String> = ArrayList(4)
        textView14.visibility = View.INVISIBLE
        wallTestProgressBar3.visibility = View.VISIBLE
        textView5.text = ""
        textView5.visibility = View.VISIBLE
        card_result_band_test.visibility = View.INVISIBLE
        val testObject = Tests()
        testJob = GlobalScope.launch(Dispatchers.Main) {
            val job = launch {
                startProgressBar(view)
            }
            val asyncVal = async {
                val testObject = Tests()
                testObject.bandWidthTest(view,checkFlag)
            }
            job.join()
            println("FINISH")
            println(asyncVal.await())
            testResult = asyncVal.await()
            wallTestProgressBar3.visibility = View.INVISIBLE
            textView5.visibility = View.INVISIBLE
            textView14.clearComposingText()
            textView14.visibility = View.VISIBLE
            card_result_band_test.visibility = View.VISIBLE

            comparedDevices = getRecords(mA.getD()!!)
            best_res_band_test.text = "Лучший результат - ${comparedDevices[3]}"
            own_res_band_test.text = "Ваш результат - $testResult"
            worst_res_band_test.text = "Худший результат - ${comparedDevices[1]}"

            textView14.text = "Ваше устройстро показало результат в ${testResult/comparedDevices[1].toInt()} " +
                    "лучше, чем ${comparedDevices[0]}(последнее место в рейтинге) и в ${comparedDevices[3].toInt()/testResult} " +
                    "хуже, чем ${comparedDevices[2]}(первое место в рейтинге)."

            sendBuf.add(1.0)
            sendBuf.add(testResult.toDouble())
            sendBuf.add(0.0)

            connectionService?.sendRecordToServ(sendBuf)
        }
    }

}