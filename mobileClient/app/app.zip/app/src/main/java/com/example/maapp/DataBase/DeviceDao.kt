package com.example.android.roomdevice

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query
import android.support.annotation.GuardedBy
import android.support.annotation.StringRes

@Dao
interface DeviceDao {

    @Query("SELECT * from DeviceInformation ORDER BY brickPerfomance DESC")
    fun getDevicesRecord(): LiveData<List<Device>>

    @Query("SELECT * from DeviceInformation WHERE Device LIKE '%' || :searchString || '%'")
    fun getSomeDevicesRecord(searchString: String): LiveData<List<Device>>

    @Query("SELECT * from DeviceInformation limit 1")
    fun getTopRecord(): Device

    @Query("SELECT * from DeviceInformation ORDER BY lengthPerfomance ASC limit 1")
    fun getWorstRecord() : Device


    @Insert
    fun insert(device: Device)

    @Query("DELETE FROM DeviceInformation")
    fun deleteAll()
}
