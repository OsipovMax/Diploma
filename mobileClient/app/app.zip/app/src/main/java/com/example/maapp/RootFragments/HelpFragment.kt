package com.example.maapp.RootFragments

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.example.maapp.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.application_info.*

class HelpFragment : BaseFragment() {
    override val layoutRes: Int = R.layout.application_info
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btn_g.setOnClickListener {
            fragmentNavigation.isRootFragment()
            activity?.bottom_nav?.setCurrentItem(0)

        }
    }


}
